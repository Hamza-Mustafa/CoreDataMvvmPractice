//
//  PersonViewModel.swift
//  CoreDataMvvmPractice
//
//  Created by Hamza Mustafa on 15/11/2021.
//

import Foundation
import UIKit

// we will use this code to set values on UiTableViewCell class

class PersonViewModel : NSObject {
    private var person : Person
    
    init(_ person: Person) {
        self.person = person
    }
    
    var id: String{
        get {
            return self.person.id
        }
    }
    
    var name: String{
        get {
            return self.person.name
        }
    }
    
    var city: String{
        get {
            return self.person.city
        }
    }
    
    var state: String{
        get {
            return self.person.state
        }
    }
    
    var country: String{
        get {
            return self.person.country
        }
    }
}
