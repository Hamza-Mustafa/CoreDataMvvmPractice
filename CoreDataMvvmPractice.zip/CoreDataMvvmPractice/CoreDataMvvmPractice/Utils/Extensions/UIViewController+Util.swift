//
//  UIViewController+Util.swift
//  CoreDataMvvmPractice
//
//  Created by Hamza Mustafa on 15/11/2021.
//

import Foundation
import UIKit

extension UIViewController {
    func showError(_ title: String?, _ msg: String){
        let alertController = UIAlertController(title: title, message: msg, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }
}
