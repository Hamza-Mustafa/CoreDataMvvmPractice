//
//  PersonCell.swift
//  CoreDataMvvmPractice
//
//  Created by Hamza Mustafa on 15/11/2021.
//

import UIKit

class PersonCell: UITableViewCell {
    
    @IBOutlet weak var idLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var stateLabel: UILabel!
    @IBOutlet weak var countryLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func configure(_ personViewModel: PersonViewModel){
        self.idLabel.text = personViewModel.id
        self.nameLabel.text = personViewModel.name
        self.cityLabel.text = personViewModel.city
        self.stateLabel.text = personViewModel.state
        self.countryLabel.text = personViewModel.country
    }
}
