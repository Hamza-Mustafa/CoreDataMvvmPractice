//
//  PersonListViewModel.swift
//  CoreDataMvvmPractice
//
//  Created by Hamza Mustafa on 15/11/2021.
//

import Foundation
import UIKit

protocol PersonListViewModelDelegate : NSObject {
    func parsePersonSuccess()
    func parsePersonFailure(_ message: String)
}

class PersonListViewModel: NSObject {
    
    private var persons: Array<Person> {
        didSet{
            self.delegate?.parsePersonSuccess()
        }
    }
    
    weak var delegate: PersonListViewModelDelegate?
    
    init(_ delegate: PersonListViewModelDelegate) {
        self.delegate = delegate
        self.persons = Array<Person>()
    }
    
    let contentJson = """
                      [
                        {
                          "id":"1",
                          "name":"Hamza",
                          "city":"karachi",
                          "state":"Sindh",
                          "country":"Pakistan"
                        },
                        {
                          "id":"2",
                          "name":"Mustafa",
                          "city":"karachi",
                          "state":"Sindh",
                          "country":"Pakistan"
                        },
                        {
                          "id":"3",
                          "name":"Ali",
                          "city":"karachi",
                          "state":"Sindh",
                          "country":"Pakistan"
                        },
                        {
                          "id":"4",
                          "name":"Farhan",
                          "city":"karachi",
                          "state":"Sindh",
                          "country":"Pakistan"
                        },
                        {
                          "id":"5",
                          "name":"Qadri",
                          "city":"karachi",
                          "state":"Sindh",
                          "country":"Pakistan"
                        },
                        {
                          "id":"6",
                          "name":"Zubair",
                          "city":"karachi",
                          "state":"Sindh",
                          "country":"Pakistan"
                        }
                      ]
                      """
    
    // It simply use content json to decode into Person Model. To test this add PersonListViewModel().parsePersonJson() in viewDidLoad() function present in PersonVC.swift.
    
//    func parsePersonJson() {
//          let responseData = Data(contentJson.utf8)
//
//          let decoder = JSONDecoder()
//          do {
//              let result = try decoder.decode([Person].self, from: responseData)
//              print(result)
//          } catch let error {
//              print("decoding error: \(error)")
//          }
//    }
    
    func personParseJson(){
        let responseData = Data(contentJson.utf8)
    
        let decoder = JSONDecoder()
        let managedObjectContext = CoreDataStorage.shared.managedObjectContext()
        guard let codingUserInfoKeyManagedObjectContext = CodingUserInfoKey.managedObjectContext else {
            fatalError("Failed to retrieve managed object context Key")
        }
        decoder.userInfo[codingUserInfoKeyManagedObjectContext] = managedObjectContext
        
        do {
            let result = try decoder.decode([Person].self, from: responseData)
            self.persons = result
            print(result)
        } catch let error {
            print("decoding error: \(error)")
            self.delegate?.parsePersonFailure("Your error message!")
        }
        
        CoreDataStorage.shared.clearStorage(forEntity: "Person")
        CoreDataStorage.shared.saveContext()
        
        let paths = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true)
        print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
        print(paths[0])
        
        if self.persons.count > 0 {
            let encoder = JSONEncoder()
            do {
                let encodedData = try encoder.encode(self.persons)
                print("Endoded data prints below")
                if let encodedString = String(data: encodedData, encoding: .utf8) {
                    print(encodedString)
                }
            } catch let err {
                print("encoding error \(err)")
            }
        }
    }
    
    func numberOfperson() -> Int {
        return self.persons.count
    }
    
    // We are using it to dequeue cells in PersonViewControllerTableDatasource wrt index
    func person(atIndex index: Int) -> PersonViewModel {
        return PersonViewModel(self.persons[index])
    }
}
