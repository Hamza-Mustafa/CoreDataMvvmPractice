//
//  PersonVC.swift
//  CoreDataMvvmPractice
//
//  Created by Hamza Mustafa on 15/11/2021.
//

import UIKit

class PersonVC: UITableViewController {

    var personListViewModel: PersonListViewModel!
    var personTableDataSource: PersonVCDataSource!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.estimatedRowHeight = 150
        self.tableView.rowHeight = UITableView.automaticDimension
        self.title = "Persons"
        
        self.personListViewModel = PersonListViewModel(self)
        self.personListViewModel.personParseJson()
        
        self.personTableDataSource = PersonVCDataSource(self.personListViewModel)
        self.tableView.dataSource = self.personTableDataSource
    }
}

extension PersonVC: PersonListViewModelDelegate {
    func parsePersonSuccess() {
        self.tableView.reloadData()
        print("success")
    }
    
    func parsePersonFailure(_ message: String) {
        self.showError("error", message)
    }
}
