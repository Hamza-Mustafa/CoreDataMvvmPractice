//
//  PersonVCDataSource.swift
//  CoreDataMvvmPractice
//
//  Created by Hamza Mustafa on 15/11/2021.
//

import Foundation
import UIKit

class PersonVCDataSource: NSObject, UITableViewDataSource {
   
    var personListViewModel : PersonListViewModel
    
    init(_ personListViewModel: PersonListViewModel){
        self.personListViewModel = personListViewModel
    }
    
    // MARK: - Table view data source
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.personListViewModel.numberOfperson()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "PersonCell", for: indexPath) as? PersonCell {
            let personViewModel = personListViewModel.person(atIndex: indexPath.row)
            cell.configure(personViewModel)
            return cell
        }
        return UITableViewCell()
    }
}
