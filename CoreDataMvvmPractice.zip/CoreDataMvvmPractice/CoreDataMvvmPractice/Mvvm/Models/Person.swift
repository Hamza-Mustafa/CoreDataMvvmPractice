//
//  Person.swift
//  CoreDataMvvmPractice
//
//  Created by Hamza Mustafa on 15/11/2021.
//

import UIKit
import CoreData

class Person: NSManagedObject, Codable{
    
    @NSManaged var id: String
    @NSManaged var name: String
    @NSManaged var city: String
    @NSManaged var state: String
    @NSManaged var country: String
    
    enum CodingKeys: String, CodingKey{
        case id
        case name
        case city
        case state
        case country
    }
    
    required convenience init(from decoder: Decoder) throws {
            guard let codingUserInfoKeyManagedObjectContext = CodingUserInfoKey.managedObjectContext,
                let managedObjectContext = decoder.userInfo[codingUserInfoKeyManagedObjectContext] as? NSManagedObjectContext,
                let entity = NSEntityDescription.entity(forEntityName: "Person", in: managedObjectContext) else {
                fatalError("Failed to decode User")
            }

            self.init(entity: entity, insertInto: managedObjectContext)

            let container = try decoder.container(keyedBy: CodingKeys.self)
            id = try container.decode(String.self, forKey: .id)
            name = try container.decode(String.self, forKey: .name)
            city = try container.decode(String.self, forKey: .city)
            state = try container.decode(String.self, forKey: .state)
            country = try container.decode(String.self, forKey: .country)

    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id, forKey: .id)
        try container.encode(name, forKey: .name)
        try container.encode(city, forKey: .city)
        try container.encode(state, forKey: .state)
        try container.encode(country, forKey: .country)
    }
}
